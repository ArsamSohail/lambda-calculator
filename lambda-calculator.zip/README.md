# Lambda Calculator (Java + JOptionPane)

A simple calculator using Java lambda expressions and `JOptionPane` for user input/output.

## Features
- Addition, Subtraction, Multiplication, Division
- Lambda expressions for operations
- Error handling (including division by zero)
- GUI input/output with `JOptionPane`

## How to Run

```bash
javac src/Calculator.java
java -cp src Calculator
```